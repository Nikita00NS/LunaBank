INSTRUCTIONS:

1) unzip or clone repo.
2) Create a .env file in project root with (optional) BOT_TOKEN and PORT, e.g.
   BOT_TOKEN=123:ABC
   PORT=3000
3) Run:
   npm install
   npm start
4) To run Telegram bot locally (optional):
   npm run bot
5) Deploying: push to GitHub, then connect to Render or any Node host. Use 'npm install' as build and 'npm start' as start command.
