const TelegramBot = require('node-telegram-bot-api');
if(!process.env.BOT_TOKEN){ console.log('BOT_TOKEN not set'); process.exit();}
const bot = new TelegramBot(process.env.BOT_TOKEN, {polling:true});
bot.on('message', msg => bot.sendMessage(msg.chat.id, 'LunaBank bot online'));
