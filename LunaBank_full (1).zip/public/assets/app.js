document.getElementById('reg').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const data = { fullname: fd.get('fullname'), age: fd.get('age'), currency: fd.get('currency') };
  const res = await fetch('/api/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
  const json = await res.json();
  document.getElementById('out').textContent = JSON.stringify(json, null, 2);
});
