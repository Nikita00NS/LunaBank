
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json());

function read(file){ return JSON.parse(fs.readFileSync(path.join(__dirname,'data',file))); }
function write(file,data){ fs.writeFileSync(path.join(__dirname,'data',file), JSON.stringify(data,null,2)); }

app.post('/api/register', (req,res)=>{
  const users = read('users.json');
  const {id,name} = req.body;
  if(users[id]) return res.json({ok:false, error:'Exists'});
  users[id] = {id,name,balance:0};
  write('users.json', users);
  res.json({ok:true});
});

app.get('/api/getUser', (req,res)=>{
  const id=req.query.id;
  const users=read('users.json');
  res.json(users[id]||null);
});

app.post('/api/addBalance',(req,res)=>{
  const {id,amount}=req.body;
  const users=read('users.json');
  users[id].balance += amount;
  write('users.json',users);
  res.json({ok:true});
});

app.post('/api/transfer',(req,res)=>{
  const {from,to,amount}=req.body;
  const users=read('users.json');
  if(users[from].balance<amount) return res.json({ok:false});
  users[from].balance-=amount;
  users[to].balance+=amount;
  write('users.json',users);
  res.json({ok:true});
});

app.get('/',(req,res)=>res.send("LunaBank Server Running"));

app.listen(3000,()=>console.log("Running on 3000"));
