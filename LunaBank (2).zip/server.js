
const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

function load(path){ return JSON.parse(fs.readFileSync(path,'utf8')); }
function save(path,data){ fs.writeFileSync(path,JSON.stringify(data,null,2)); }

app.get('/',(req,res)=>res.send('LunaBank API running'));

app.post('/register',(req,res)=>{
  const db = load('./data/users.json');
  const {id,name}=req.body;
  if(!id||!name) return res.status(400).json({error:'Missing fields'});
  if(db.users && db.users.find(u=>u.id===id)) return res.status(400).json({error:'Exists'});
  if(!db.users) db.users=[];
  db.users.push({id,name,balance:0});
  save('./data/users.json',db);
  res.json({ok:true});
});

const PORT = process.env.PORT || 3000;
app.listen(PORT,()=>console.log('Server on '+PORT));
