
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/api/ping', (req,res)=>res.json({ok:true}));

const PORT = process.env.PORT || 10000;
app.listen(PORT, ()=> console.log("API running on port", PORT));
