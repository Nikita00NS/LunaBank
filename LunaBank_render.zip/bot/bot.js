
const TelegramBot = require('node-telegram-bot-api');
const token = process.env.TELEGRAM_TOKEN;
if(!token){ console.error("No TELEGRAM_TOKEN"); process.exit(1); }
const bot = new TelegramBot(token, { polling: true });
bot.on('message', msg => bot.sendMessage(msg.chat.id, "LunaBank bot работает!"));
